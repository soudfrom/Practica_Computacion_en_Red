#!/usr/bin/python
#-*- coding: utf-8 -*-

""" Directiva encoding necesaria introducir al principio del código en python, para que el sistema interprete caracteres especiales como la ñ """
#-*- coding: uth-8 -*-

from flask import Flask, url_for, render_template, request # Importar clase flask
import urllib2 # Necesario para acceder a internet
import re # Necesario para expresiones regulares
import json
import ssl
#from time import gmtime, strftime
#import requests
from beebotte import *
from pymongo import MongoClient #Libreria para datos con pymongo
import time


app = Flask(__name__)  # Instancia de esta clase, que tendrá un solo módulo
bclient = BBT('NWTsJRTJWghpprLrvGUgdQdX', 'JU9zs9XwzMghKwSkzOkyBIceNH3HWEO0') #Definicion inicial para utilizar beebotte

@app.route('/')
def index():
	pag_web = urllib2.urlopen('https://www.meneame.net/rss')
	codigo = pag_web.read() # Leemos la pag y lo guardamos en codigo

	titulos = re.findall(r'<title>(.*?)</title>',codigo.decode('utf-8'))
	primer_titulo = titulos[2][0:]

	meneos_totales = re.findall(r'<meneame:votes>(\S+)',codigo)
	meneos_ = (re.findall(r'(\d+)', str(meneos_totales)))
	num_meneo = int(meneos_[0])

	clicks_totales = re.findall(r'<meneame:clicks>(\S+)',codigo)
	clicks_ = (re.findall(r'(\d+)', str(clicks_totales)))
	num_clicks = int(clicks_[0])

	karma_totales = re.findall(r'<meneame:karma>(\S+)',codigo)
	karma_ = (re.findall(r'(\d+)', str(karma_totales)))
	num_karma = int(karma_[0])

	comentarios_totales = re.findall(r'<meneame:comments>(\S+)',codigo)
	comentarios_ = (re.findall(r'(\d+)', str(comentarios_totales)))
	num_comentarios = int(comentarios_[0])

	negativos_totales = re.findall(r'<meneame:negatives>(\S+)',codigo)
	negativos_ = (re.findall(r'(\d+)', str(negativos_totales)))
	num_negativos = int(negativos_[0])
	
	fecha_ = time.strftime("%x") # Obtenemos la fecha
	hora_ = time.strftime("%X") # Obtenemos la hora

	#------BEEBOTTE--------
	#Tenemos que introducir los datos en nuestra base externa
	#bclient = BBT('NWTsJRTJWghpprLrvGUgdQdX', 'JU9zs9XwzMghKwSkzOkyBIceNH3HWEO0')
	#bclient.write("test","meneos",num_meneo)
	meneos = Resource(bclient, "practica", "meneos") #Create a Resource object
	bbt_meneos = meneos.write(num_meneo)

	clicks = Resource(bclient, "practica", "clicks") #Create a Resource object
	bbt_clicks = clicks.write(num_clicks)

	titulo = Resource(bclient, "practica", "titulo") #Create a Resource object
	bbt_titulo = titulo.write(primer_titulo)

	karma = Resource(bclient, "practica", "karma") #Create a Resource object
	bbt_karma = karma.write(num_karma)

	comentarios = Resource(bclient, "practica", "comentarios") #Create a Resource object
	bbt_comentarios = comentarios.write(num_comentarios)

	negativos = Resource(bclient, "practica", "negativos") #Create a Resource object
	bbt_negativos = negativos.write(num_negativos)

	fecha = Resource(bclient, "practica", "fecha") #Create a Resource object
	bbt_fecha = fecha.write(fecha_)

	hora = Resource(bclient, "practica", "hora") #Create a Resource object
	bbt_hora = hora.write(hora_)

	#-------------MONGODB------------------
	#Tenemos que meter datos a nuestra BBDD local 
	client = MongoClient('localhost',27017)
	db = client.test
	users = db.users

	users = client.test.users #Forma acotada de lo anterior

	#Preparamos el documento JSON que vamos a insertar
	meneos_mongo = num_meneo
	titulo_mongo = primer_titulo
	clicks_mongo = num_clicks
	karma_mongo = num_karma
	comentarios_mongo = num_comentarios
	negativos_mongo = num_negativos
	fecha_mongo = fecha_
	hora_mongo = hora_

	#Insertamos datos en MongoDB --dicci
	user = {
	'meneos' : meneos_mongo,
	'titulo' : titulo_mongo,
	'clicks' : clicks_mongo,
	'karma' : karma_mongo,
	'comentarios' : comentarios_mongo,
	'negativos' : negativos_mongo,
	'fecha' : fecha_mongo,
	'hora' : hora_mongo
	}

	result = users.insert_one(user) #Sirve para rellenar datos en MongoDB
	contador = users.find().count() #Nos devuelve la cantidad de datos almacenados

	#Tenemos que calcular la media de los datos almacenados en nuestra base de datos
	media_mongo = 0
	media_bbt = 0
	i = 0
	j = 0

	for user in users.find():
		media_mongo = media_mongo + user['clicks']
		i = i + 1

	clicks = Resource(bclient, "practica", "clicks")

	for externa in clicks.read(limit = 800):
		media_bbt = media_bbt + float(externa["data"])
		i = i + 1

	media_total_mongo = media_mongo / contador

	media_total_bbt = media_bbt / i

	global flag

	if flag == 0:
		media_final = media_total_mongo
		ext_int = 'local MongoDB'

	if flag == 1:
		media_final = media_total_bbt
		ext_int = 'externa Beebotte'

	if flag == 1:
		flag = 0

	else:
		flag = 1

	return render_template('pag_web.html', titulo = primer_titulo, meneos = num_meneo, fecha = fecha_, hora = hora_, clicks = num_clicks, karma = num_karma, comentarios = num_comentarios, negativos = num_negativos)
	#return render_template('pag_web.html', meneos = meneos_)

@app.route('/umbral', methods=['POST'])
def meneos_superiores():
	
		umbral_puesto = float(request.form['val_sup'])
		umbral_mostrado = str(umbral_puesto)

		client = MongoClient('localhost', 27017)
		db = client.test
		users = db.users

		users = client.test.users
		valores = ' '

		for i in users.find({"meneos": {"$gt": umbral_puesto}}): #$gt selecciona los doc donde "meneos" es mayor que lo pedido
		#for i in users.find().limit(total - N):
			valores = valores + i['titulo'] + '&nbsp;&nbsp;' + str(i['meneos']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['fecha']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['hora']) + '<br>'
		return render_template('umbral.html', titulo = i['titulo'], umbral = umbral_mostrado, umbral_superior = valores, ultimo_meneo = str(i['meneos']), ultimo_fecha = str(i['fecha']), ultimo_hora = str(i['hora']))

@app.route('/karma', methods=['POST'])
def karmas_superiores():
	
		karma_puesto = float(request.form['karma_sup'])
		karma_mostrado = str(karma_puesto)

		client = MongoClient('localhost', 27017)
		db = client.test
		users = db.users

		users = client.test.users
		valores_karma = ' '

		for i in users.find({"karma": {"$gt": karma_puesto}}): #$gt selecciona los doc donde "meneos" es mayor que lo pedido
		#for i in users.find().limit(total - N):
			valores_karma = valores_karma + i['titulo'] + '&nbsp;&nbsp;' + str(i['karma']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['fecha']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['hora']) + '<br>'
		return render_template('karma.html', titulo = i['titulo'], karma = karma_mostrado, karma_superior = valores_karma, ultimo_karma = str(i['karma']), ultimo_fecha = str(i['fecha']), ultimo_hora = str(i['hora']))

@app.route('/clicks', methods=['POST'])
def clicks_superiores():
	
		click_puesto = float(request.form['clicks_sup'])
		click_mostrado = str(click_puesto)

		client = MongoClient('localhost', 27017)
		db = client.test
		users = db.users

		users = client.test.users
		valores_click = ' '

		for i in users.find({"clicks": {"$gt": click_puesto}}): #$gt selecciona los doc donde "meneos" es mayor que lo pedido
		#for i in users.find().limit(total - N):
			valores_click = valores_click + i['titulo'] + '&nbsp;&nbsp;' + str(i['clicks']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['fecha']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['hora']) + '<br>'
		return render_template('clicks.html', titulo = i['titulo'], click = click_mostrado, click_superior = valores_click, ultimo_click = str(i['clicks']), ultimo_fecha = str(i['fecha']), ultimo_hora = str(i['hora']))

@app.route('/comentario', methods=['POST'])
def comentarios_superiores():
	
		comentario_puesto = float(request.form['comentarios_sup'])
		comentario_mostrado = str(comentario_puesto)

		client = MongoClient('localhost', 27017)
		db = client.test
		users = db.users

		users = client.test.users
		valores_comentario = ' '

		for i in users.find({"comentarios": {"$gt": comentario_puesto}}): #$gt selecciona los doc donde "meneos" es mayor que lo pedido
		#for i in users.find().limit(total - N):
			valores_comentario = valores_comentario + i['titulo'] + '&nbsp;&nbsp;' + str(i['comentarios']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['fecha']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['hora']) + '<br>'
		return render_template('comentario.html', titulo = i['titulo'], comentario = comentario_mostrado, comentario_superior = valores_comentario, ultimo_comentario = str(i['comentarios']), ultimo_fecha = str(i['fecha']), ultimo_hora = str(i['hora']))

"""
@app.route('/negativos', methods=['POST'])
def negativos_superiores():
	
		negativo_puesto = float(request.form['negativos_sup'])
		negativo_mostrado = str(negativo_puesto)

		client = MongoClient('localhost', 27017)
		db = client.test
		users = db.users

		users = client.test.users
		valores_negativos = ' '
		i = 1

		for i in users.find({"negativo": {"$gt": negativo_puesto}}): #$gt selecciona los doc donde "meneos" es mayor que lo pedido
		#for i in users.find().limit(total - N):
			valores_negativos = valores_negativos + i['titulo'] + '&nbsp;&nbsp;' + str(i['negativo']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['fecha']) + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + str(i['hora']) + '<br>'
		return render_template('negativos.html', titulo = i['titulo'], negativos = karma_mostrado, negativo_superior = valores_negativos, ultimo_negativo = str(i['negativos']), ultimo_fecha = str(i['fecha']), ultimo_hora = str(i['hora']))
"""

if __name__ == '__main__':
	global flag
	flag = 0
	app.debug = True
	app.run(host = '0.0.0.0')

