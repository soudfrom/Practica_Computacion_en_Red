#!/usr/bin/python
#-*- coding: utf-8 -*-

""" Directiva encoding necesaria introducir al principio del código en python, para que el sistema interprete caracteres especiales como la ñ """
#-*- coding: uth-8 -*-

from flask import Flask, url_for, render_template, request # Importar clase flask
import urllib2 # Necesario para acceder a internet
import re # Necesario para expresiones regulares
import json
import ssl
#import requests
from beebotte import *
from pymongo import MongoClient #Libreria para datos con pymongo
import time


pag_web = urllib2.urlopen('https://www.meneame.net/rss')
codigo = pag_web.read() # Leemos la pag y lo guardamos en codigo

titulos = re.findall(r'<title>(.*?)</title>',codigo.decode('utf-8'))
primer_titulo = titulos[2][0:]

meneos_totales = re.findall(r'<meneame:votes>(\S+)',codigo)
meneos_ = (re.findall(r'(\d+)', str(meneos_totales)))
num_meneo = int(meneos_[0])

clicks_totales = re.findall(r'<meneame:clicks>(\S+)',codigo)
clicks_ = (re.findall(r'(\d+)', str(clicks_totales)))
num_clicks = int(clicks_[0])

karma_totales = re.findall(r'<meneame:karma>(\S+)',codigo)
karma_ = (re.findall(r'(\d+)', str(karma_totales)))
num_karma = int(karma_[0])

comentarios_totales = re.findall(r'<meneame:comments>(\S+)',codigo)
comentarios_ = (re.findall(r'(\d+)', str(comentarios_totales)))
num_comentarios = int(comentarios_[0])

negativos_totales = re.findall(r'<meneame:negatives>(\S+)',codigo)
negativos_ = (re.findall(r'(\d+)', str(negativos_totales)))
num_negativos = int(negativos_[0])
	
fecha_ = time.strftime("%x") # Obtenemos la fecha
hora_ = time.strftime("%X") # Obtenemos la hora

print num_meneo

#------BEEBOTTE--------
#bclient = BBT('NWTsJRTJWghpprLrvGUgdQdX', 'JU9zs9XwzMghKwSkzOkyBIceNH3HWEO0')
#bclient.write("test","meneos",num_meneo)
bclient = BBT('NWTsJRTJWghpprLrvGUgdQdX', 'JU9zs9XwzMghKwSkzOkyBIceNH3HWEO0')
meneos = Resource(bclient, "practica", "meneos") #Create a Resource object
bbt_meneos = meneos.write(num_meneo)

clicks = Resource(bclient, "practica", "clicks") #Create a Resource object
bbt_clicks = clicks.write(num_clicks)

titulo = Resource(bclient, "practica", "titulo") #Create a Resource object
bbt_titulo = titulo.write(primer_titulo)

karma = Resource(bclient, "practica", "karma") #Create a Resource object
bbt_karma = karma.write(num_karma)

comentarios = Resource(bclient, "practica", "comentarios") #Create a Resource object
bbt_comentarios = comentarios.write(num_comentarios)

negativos = Resource(bclient, "practica", "negativos") #Create a Resource object
bbt_negativos = negativos.write(num_negativos)

fecha = Resource(bclient, "practica", "fecha") #Create a Resource object
bbt_fecha = fecha.write(fecha_)

hora = Resource(bclient, "practica", "hora") #Create a Resource object
bbt_hora = hora.write(hora_)

#Tenemos que meter datos a nuestra BBDD local ---> MongoDB
client = MongoClient('localhost',27017)
db = client.test
users = db.users

users = client.test.users #Forma acotada de lo anterior

#Preparamos el documento JSON que vamos a insertar
meneos_mongo = num_meneo
titulo_mongo = primer_titulo
clicks_mongo = num_clicks
karma_mongo = num_karma
comentarios_mongo = num_comentarios
negativos_mongo = num_negativos
fecha_mongo = fecha_
hora_mongo = hora_

#Insertamos datos en MongoDB
user = {
'meneos' : meneos_mongo,
'titulo' : titulo_mongo,
'clicks' : clicks_mongo,
'karma' : karma_mongo,
'comentarios' : comentarios_mongo,
'negativos' : negativos_mongo,
'fecha' : fecha_mongo,
'hora' : hora_mongo
}

result = users.insert_one(user)